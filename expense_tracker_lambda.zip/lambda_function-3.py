### Required Libraries ###
from datetime import datetime
from dateutil.relativedelta import relativedelta
from botocore.vendored import requests

### Functionality Helper Functions ###

### Dialog actions helper Functions ###
def build_validation_result(is_valid, violated_slot, message_content):
    """
    Defines an internal validation message structured as a python dictionary.
    """
    if message_content is None:
        return {"isValid": is_valid, "violatedSlot": violated_slot}
    return {
        "isValid": is_valid,
        "violatedSlot": violated_slot,
        "message": {"contentType": "PlainText", "content": message_content},
    }
def validate_data(expenses, intent_request):
    """
    Validates the data provided by the user.
    """

    # Validate that the user is over 21 years old
    if expenses is not None:
        valid_expenses = ["Water", "Electric", "Medical Insurance", "Car Loan","Mortgage"]
        if expenses not in valid_expenses:
            return build_expenses_result(
                False,
                "expenses",
                "Please enter valid expenses.",
            )

    # A True results is returned if age or amount are valid
    return build_validation_result(True, None, None)

### Dialog Actions Helper Functions ###
def get_slots(intent_request):
    """
    Fetch all the slots and their values from the current intent.
    """
    return intent_request["currentIntent"]["slots"]

def elicit_slot(session_attributes, intent_name, slots, slot_to_elicit, message):
    """
    Defines an elicit slot type response.
    """

    return {
        "sessionAttributes": session_attributes,
        "dialogAction": {
            "type": "ElicitSlot",
            "intentName": intent_name,
            "slots": slots,
            "slotToElicit": slot_to_elicit,
            "message": message,
        },
    }

def delegate(session_attributes, slots):
    """
    Defines a delegate slot type response.
    """

    return {
        "sessionAttributes": session_attributes,
        "dialogAction": {"type": "Delegate", "slots": slots},
    }


def close(session_attributes, fulfillment_state, message):
    """
    Defines a close slot type response.
    """

    response = {
        "sessionAttributes": session_attributes,
        "dialogAction": {
            "type": "Close",
            "fulfillmentState": fulfillment_state,
            "message": message,
        },
    }

    return response

def configure_message(expenses):
    message = "empty message"
    
    if expenses == "Water":
        message = """Expenses Payment Due Date: July 2, 2022
                     Expenses Payment Amount: $95
                     Expenses Next Payment Due Date: August 2, 2022 """
    
    elif expenses == "Electric":
        message = """Expenses Payment Due Date: July 1, 2022
                     Expenses Payment Amount: $150
                     Expenses Next Payment Due Date: August 1, 2022"""
                     
    elif expenses == "Medical Insurance":
        message = """Expenses Payment Due Date:July 15, 2022
                     Expenses Payment Amount: $183
                     Expenses Next Payment Due Date:August 15, 2022"""
    
    elif expenses == "Car Loan":
        message = """Expenses Payment Due Date: July 31, 2022
                     Expenses Payment Amount: $274.95
                     Expenses Remaining Balance: $7,989  """
                     
    elif expenses == "Mortgage":
        message = """Expenses Payment Due Date: August 5, 2022
                     Expenses Payment Amount: $1,318
                     Expenses Remaining Balance: $50,879 """
                     
    return message
### Intents Handlers ###

def fetch_expenses_details(intent_request):
    """
    Performs dialog management and fulfillment for converting from dollars to bitcoin.
    """

    # Gets slots' values
    expenses = get_slots(intent_request)["expenses"]

    # Gets the invocation source, for Lex dialogs "DialogCodeHook" is expected.
    source = intent_request["invocationSource"]  #

    if source == "DialogCodeHook":
        # This code performs basic validation on the supplied input slots.

        # Gets all the slots
        slots = get_slots(intent_request)

        # Validates user's input using the validate_data function
        validation_result = validate_data(expenses, intent_request)

        # If the data provided by the user is not valid,
        # the elicitSlot dialog action is used to re-prompt for the first violation detected.
        if not validation_result["isValid"]:
            slots[validation_result["violatedSlot"]] = None  # Cleans invalid slot
            # Returns an elicitSlot dialog to request new data for the invalid slot
            return elicit_slot(
                intent_request["sessionAttributes"],
                intent_request["currentIntent"]["name"],
                slots,
                validation_result["violatedSlot"],
                validation_result["message"],
            )

        # Fetch current session attributes
        output_session_attributes = intent_request["sessionAttributes"]

        # Once all slots are valid, a delegate dialog is returned to Lex to choose the next course of action.
        return delegate(output_session_attributes, get_slots(intent_request))
    
    message = configure_message(expenses)

    # Return a message with conversion's result.
    return close(
        intent_request["sessionAttributes"],
        "Fulfilled",
        {
            "contentType": "PlainText",
            "content": message,
        },
    )

### Intents Dispatcher ###
def dispatch(intent_request):
    """
    Called when the user specifies an intent for this bot.
    """

    # Get the name of the current intent
    intent_name = intent_request["currentIntent"]["name"]

    # Dispatch to bot's intent handlers
    if intent_name == "ExpenseTracker":
        return fetch_expenses_details(intent_request)
        
    
    raise Exception("Intent with name " + intent_name + " not supported")


### Main Handler ###
def lambda_handler(event, context):
    """
    Route the incoming request based on intent.
    The JSON body of the request is provided in the event slot.
    """

    return dispatch(event)